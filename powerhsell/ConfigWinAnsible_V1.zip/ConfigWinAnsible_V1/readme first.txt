## Author: Bruno L. Bertozzo de A. Arruda (barruda@br.ibm.com)
## (Finance & Supply Chain Enablers squad member - GI_SSC_ENABLERS)

###############################################################

IMPORTANT!

- Copy the script folder content to a temp folder on your server;

- Make sure the account you are using to run this script has admin permissions;

- To run the script double click run_step1.bat file (DON'T NEED to right-click and select "Run As Administrator", the script will do it automatically).

###############################################################

INSTRUCTIONS:


This script will enable WinRM and configure it to allow connections via HTTPS (port 5986) using CredSSP authentication mode.

A new certificate will be imported to the "Personal" certificates folder (Computer) installed both on WinRM HTTPS connector and WinRM CredSSP service level. Using HTTPS (port 5986) will make sure all traffic is encrypted end-to-end.

After running this script, you will be able to connect from Ansible to Windows hosts, using a local or domain user account.

Ansible inventory file can be configured as per example bellow:

[windows]
YourWindowsServerIPorHostname

[windows:vars]
ansible_connection=winrm
ansible_user=domain\theusercreatedlocallyorondomain
ansible_password=theuserpassword
ansible_winrm_transport=credssp
ansible_winrm_server_cert_validation=ignore

Ansible inventory on CIO Tower can be configured as per example bellow:

---
ansible_connection: winrm
ansible_winrm_transport: credssp
ansible_winrm_server_cert_validation: ignore



It is highly recommended when using Ansible CIO Tower that you use the password encryption option in the playbook itself via Survey (variable: ansible_password) or creating a "machine" type credential. When using "machine" type credential with Windows domain account, the username will be user@domain instead domain\user. For local accounts, just type the username.


##########################################################################################